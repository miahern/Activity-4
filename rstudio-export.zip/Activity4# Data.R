install.packages("tidyverse")
library("tidyverse")
data <- mtcars
summary(data)
ggplot(data, aes(x = mpg, y = hp)) +
  geom_point() +
  labs(title = "MPG VS Horsepower")
