install.packages("quanteda")
install.packages("quanteda.textmodels")
install.packages("quanteda.textplots")
